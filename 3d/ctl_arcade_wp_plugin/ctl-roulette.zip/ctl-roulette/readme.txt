=== CTL Roulette ===
Tags: bet, casino, casino game, gambling, game, instant win, mobile, poker, roulette, roulette game, sweepstakes, table, texas, wheel
Requires at least: 4.3
Tested up to: 4.3

Add Roulette to CTL Arcade plugin

== Description ==
Add Roulette to CTL Arcade plugin


	